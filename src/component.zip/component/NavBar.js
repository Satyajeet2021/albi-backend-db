import React,{useEffect,useState} from 'react'
import { Link } from 'react-router-dom'
import {useDispatch,useSelector} from "react-redux"
import {GetAllCategory} from "../action"

export default function NavBar() {

const categoryValue = useSelector(state=>state?.category)
  const dispatch = useDispatch();
const data = {genderBased:categoryValue?.gender}
  useEffect(() => {
    dispatch(GetAllCategory(data));
  }, []);

   //  const renderCategories=(categoryData)=>{ 
   //  var categoriesList=[]; 
   //  for(var cate of categoryData){
   //    categoriesList?.push({
   //              label:cate?.name,
   //              value:cate?._id,
   //              parentId:cate?.parentId,
   //              children:cate?.children?.length>0 && renderCategories(cate?.children)
   //            });
   //   }
   //  return categoriesList;
   // }

 const renderCategories = (categories) => {
    let myCategories = [];
    var i=0 
    for (let category of categories) { 
    	// console.log(category)
      myCategories.push(
        <li className="ruby-menu-mega item"   key={category.name}>
          {
            category.parentId ? <a
              href={`/${category.slug}?cid=${category._id}&type=${category.type}`}>
              {category.name}
            </a> : 
            <Link
              to={`/${category.slug}/${category.unqId}`}>
              {category?.children?.length>0 ?"":<img src={category?.categoryIcon} className="h-5 w-5"/>}
              <span className="px-1">{category.name}</span>
            </Link>
          }
          {i+1 && category.children.length > 0 ? (
          <div className="ruby-grid ruby-grid-lined">
              <div className="ruby-row  container mx-auto">
                <div className='ruby-col-10'>
                  <ul className="ColumnMenuLevel__list w-full bg-white">{renderCategories(category.children)}</ul>
                </div>
                <div className="ruby-col-2">
                  <div className="ColumnMenuLevel__btn_all ml-auto mr-0 mb-auto">
                    <a href="#" aria-current="page" className="active">
                      <div className="ColumnMenuLevel__btn_all__image">
                        <img src="https://albionline.com/static/media/image-3.3b9cbf9f.png" alt="asd" className="Image"/>
                      </div>
                      <div className="ColumnMenuLevel__btn_all__text">
                        <span>All</span>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            </div>) : null}
        </li>
      );
    }
    return myCategories;
  }



	return ( 

<div className="ruby-menu-demo-header   mx-auto w-full">
      <div className="ruby-wrapper   container">
        <button className="c-hamburger c-hamburger--htx visible-xs">
          <span>toggle menu</span>
        </button>
        <ul className="ruby-menu"> 
         
        {categoryValue?.categories?.categoryList?.length > 0 ? renderCategories(categoryValue?.categories?.categoryList) : null}
        <li>
          <input type="text" className="p-2 rounded-3xl w-2/12 border border-gray-100 text-gray-800 bg-gray-100 px-5 searchright" placeholder="Search"/>
          </li>
        </ul>
        
      </div>
</div>
	)
}