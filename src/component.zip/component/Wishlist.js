import React from 'react'
import { Link } from 'react-router-dom'
import Header from "../component/Header";
import Footer from "../component/Footer"

export default function Cart() {
	return (
		<div>
		<Header/>
		<div className="flex container mx-auto w-6/12 p-10 items-center justify-center">
		<div className="text-center">
			<h1 className="font-semibold text-3xl p-2">Wishlist</h1>
			<p className="p-5">Currently you don't have any products in your list</p>
			<div>
			<button className="border border-gray-500 px-10 py-3 hover:bg-black hover:text-white">Add Products</button>
			</div>
			</div>
		</div>
		<Footer/>
			
		</div>
	)
}